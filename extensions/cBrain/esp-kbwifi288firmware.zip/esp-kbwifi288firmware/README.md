# funXtcp
esp8266 WiFi firmware to connect funXbot with funXblock

The recommended connections for an esp-12 module are:

URXD: connect to TX of microcontroller
UTXD: connect to RX of microcontroller
GPIO12: connect to RESET of microcontroller
GPIO0: either a 1k-10k pull-up resistor to 3.3v or a green "conn" LED via a 1k-2.2k resistor to 3.3V (indicates wifi status)
GPIO2: either a 1k-10k pull-up resistor to 3.3v or a yellow "ser" LED via a 1k-2.2k resistor to 3.3V (indicates serial activity)


# Hardware configuration for flashing
To flash firmware onto the esp8266 via the serial port, the following must be observed:

GPIO0 must be low when reset ends to put the esp8266 into flash programming mode, it must be high to enter normal run mode
GPIO2 must be high (pull-up resistor)
GPIO15 must be low (pull-down resistor)

Initial serial flashing
32Mbit / 4Mbyte module

espflash_download_tool 需以管理員身分執行
0x00000   boot_v1.7.bin
0x1000    user1.bin
0x3FC000  esp_init_data_default_v08.bin
0x3FE000  blank.bin

or 
esptool.py --port /dev/ttyUSB0 --baud 230400 write_flash -fs 32m -ff 80m \
    0x00000 boot_v1.7.bin 0x1000 user1.bin \
    0x3FC000 esp_init_data_default_v08.bin 0x3FE000 blank.bin
